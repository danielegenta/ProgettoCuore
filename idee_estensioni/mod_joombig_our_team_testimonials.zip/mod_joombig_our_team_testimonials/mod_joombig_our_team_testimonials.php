<?php
/**
* @title		Joombig our team testimonials
* @website		http://www.joombig.com
* @copyright	Copyright (C) 2014 joombig.com. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/
    // no direct access
    defined('_JEXEC') or die('Restricted access');
	$mosConfig_absolute_path = JPATH_SITE;
	$mosConfig_live_site = JURI :: base();
	if(substr($mosConfig_live_site, -1)=="/") { $mosConfig_live_site = substr($mosConfig_live_site, 0, -1); }

    $module_name             = basename(dirname(__FILE__));
    $module_dir              = dirname(__FILE__);
    $module_id               = $module->id;
    $document                = JFactory::getDocument();
    $style                   = $params->get('sp_style');

    if( empty($style) )
    {
        JFactory::getApplication()->enqueueMessage( 'Slider style no declared. Check Joombig our team testimonials configuration and save again from admin panel' , 'error');
        return;
    }

    $layoutoverwritepath     = JURI::base(true) . '/templates/'.$document->template.'/html/'. $module_name. '/tmpl/'.$style;
    $document                = JFactory::getDocument();
    require_once $module_dir.'/helper.php';
    $helper = new mod_Ourteamtestimonials($params, $module_id);
    $data = (array) $helper->display();
	$width_module				= $params->get('width_module', "960");
	$height_module 				= $params->get('height_module', "200");
	
	$left_image 				= $params->get('left_image', "0");
	$top_image					= $params->get('top_image','0');
	
	$background					= $params->get('background','#fff');
	
	$enable_jquery				= $params->get('enable_jquery',1);
	
	$font_size_intro			= $params->get('font_size_intro', "13");
	$color_intro 				= $params->get('color_intro','#fff');
	
	$font_size_author			= $params->get('font_size_author','12');
	$color_author				= $params->get('color_author','#666');
	
	$color_des_author			= $params->get('color_des_author','333');
	$font_size_des_author		= $params->get('font_size_des_author','12');
    //$option = (array) $params->get('animation')->$style;
    if(  is_array( $helper->error() )  )
    {
        JFactory::getApplication()->enqueueMessage( implode('<br /><br />', $helper->error()) , 'error');
    } else {
        if( file_exists($layoutoverwritepath.'/view.php') )
        {
            require(JModuleHelper::getLayoutPath($module_name, $layoutoverwritepath.'/view.php') );   
        } else {
            require(JModuleHelper::getLayoutPath($module_name, $style.'/view') );   
        }

        $helper->setAssets($document, $style);
}