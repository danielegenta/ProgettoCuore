<?php
/**
* @title		Joombig our team testimonials
* @website		http://www.joombig.com
* @copyright	Copyright (C) 2014 joombig.com. All rights reserved.
* @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
*/

    // no direct access
    defined('_JEXEC') or die;
?>

<!-- STYLESHEET -->
<link rel="stylesheet" type="text/css" href="<?php echo $mosConfig_live_site; ?>/modules/mod_joombig_our_team_testimonials/tmpl/Ourteamtestimonials/js/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $mosConfig_live_site; ?>/modules/mod_joombig_our_team_testimonials/tmpl/Ourteamtestimonials/js/bootstrap-responsive.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $mosConfig_live_site; ?>/modules/mod_joombig_our_team_testimonials/tmpl/Ourteamtestimonials/js/preset1.css">


<!-- SCRIPTS-->
<?php if($enable_jquery == 1){?>
	<script type="text/javascript" src="<?php echo $mosConfig_live_site; ?>/modules/mod_joombig_our_team_testimonials/tmpl/Ourteamtestimonials/js/jquery.min.js"></script>
<?php }?>
<script type="text/javascript" src="<?php echo $mosConfig_live_site; ?>/modules/mod_joombig_our_team_testimonials/tmpl/Ourteamtestimonials/js/jquery-noconflict.js"></script>
<script type="text/javascript" src="<?php echo $mosConfig_live_site; ?>/modules/mod_joombig_our_team_testimonials/tmpl/Ourteamtestimonials/js/ourteam.js"></script>
<?php $document->addStyleSheet('modules/mod_joombig_our_team_testimonials/tmpl/Ourteamtestimonials/js/preset1.css');
	$document->addStyleDeclaration('
		#monialsfader {
			width:'.$width_module.'px;
			height:'.$height_module.'px;
		}
		#sp-testimonial-wrapper #monialsfader #monials li .img {
			top:'.$top_image.'px;
			left:'.$left_image.'px;
			background:'.$background.';
		}
		#sp-testimonial-wrapper #monialsfader #monials li .testimonials {
			font-size:'.$font_size_intro.'px;
			color:'.$color_intro.';
		}
		#sp-testimonial-wrapper #monialsfader #monials li .author .author_desi {
			font-size:'.$font_size_author.'px;
			color:'.$color_des_author.';
		}
		#sp-testimonial-wrapper #monialsfader #monials li .author .author_name {
			font-size:'.$font_size_des_author.'px;
			color:'.$color_author.';
		}
		#sp-testimonial-wrapper #monialsfader #monials li .testi_text{
			background:'.$background.';
		}
');
?>


 <div id="sp-testimonial-wrapper">
	<div class="mod-wrapper-flat clearfix">
		<div id="monialsfader">
			<div id="inner-monialsfader">
				<ul id="monials">
				<?php 
					$count=1;
				foreach($data as $index => $value) {
					if($count==1) {
				?>
					<li class="active" style="opacity: 1;">
						<div class="img">
							<img src="<?php echo $value['image'];?>" width="120px"> 
						</div>
						<div class="testi_bg">
							<div class="testi_text">						
								<div class="testimonials">
									<?php echo $value['description'];?>	
								</div>
							</div>
						</div>
						<div class="imghol">
							<div class="author">
								<span class="author_name"><?php echo $value['title'];?></span>
								<span class="author_desi"><?php echo $value['desauthor'];?></span>
							</div>
						</div>
					</li>
				<?php } else { ?>
					<li class="" style="opacity: 0;">
						<div class="img">
							<img src="<?php echo $value['image'];?>" width="120px"> 
						</div>
						<div class="testi_bg">
							<div class="testi_text">						
								<div class="testimonials">
									<?php echo $value['description'];?>
								</div>
							</div>
						</div>
						<div class="imghol">
							<div class="author">
								<span class="author_name"><?php echo $value['title'];?></span>
								<span class="author_desi"><?php echo $value['desauthor'];?></span>
							</div>
						</div>
					</li>
				<?php } $count++;} ?>	
				</ul>
				<div id="monials-top">
				</div>
				<div id="monialsfader_next" style="display: none;">
					<img src="<?php echo $mosConfig_live_site; ?>/modules/mod_joombig_our_team_testimonials/tmpl/Ourteamtestimonials/js/next.png" alt="Next">
				</div>
				<div id="monialsfader_prev" style="display: none;">
					<img src="<?php echo $mosConfig_live_site; ?>/modules/mod_joombig_our_team_testimonials/tmpl/Ourteamtestimonials/js/prev.png" alt="Prev">
				</div>
			</div>
		</div>
	</div>
</div>


